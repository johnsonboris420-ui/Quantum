"""Mandelbulb 4D fractal visualization module."""
from .mandelbulb_4d import compute_mandelbulb, extract_isosurface, render_main_view
